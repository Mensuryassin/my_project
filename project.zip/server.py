from flask_app.controller import users, videos
from flask_app import app


if __name__=="__main__":
    app.run(debug=True)